package ar.org.centro.java.curso.entidades;

import java.text.DecimalFormat;

public abstract class Vehiculo implements Comparable<Vehiculo> {

    private String marca;
    private String modelo;
    private double precio;

    public Vehiculo(String marca, String modelo, double precio) {
        this.marca = marca;
        this.modelo = modelo;
        this.precio = precio;
    }

    public static String CreaDF(double numero) {
        DecimalFormat df = new DecimalFormat("#,###.00");
        return df.format(numero);
    }

    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public double getPrecio() {
        return precio;
    }

    @Override
    public int compareTo(Vehiculo otroAuto) {
        int result = this.marca.compareTo(otroAuto.marca);
        if (result != 0) {
            return result;
        }

        result = this.modelo.compareTo(otroAuto.modelo);
        if (result != 0) {
            return result;
        }

        return Double.compare(this.precio, otroAuto.precio);
    }

}
