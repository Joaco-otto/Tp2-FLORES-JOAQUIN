package ar.org.centro.java.curso.test;

import ar.org.centro.java.curso.entidades.ConcesionariaAutosMotos;

public class Concesionaria {

        public static void main(String[] args) {
                ConcesionariaAutosMotos concesionaria = new ConcesionariaAutosMotos();
                concesionaria.ejecutar();
                System.out.println();
                System.out.println("    ==    FIN DEL PROGRAMA      ==\n");

        }

}
