package ar.org.centro.java.curso.TP2_FloresJoaquin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tp2FloresJoaquinApplication {

	public static void main(String[] args) {
		SpringApplication.run(Tp2FloresJoaquinApplication.class, args);
	}

}
