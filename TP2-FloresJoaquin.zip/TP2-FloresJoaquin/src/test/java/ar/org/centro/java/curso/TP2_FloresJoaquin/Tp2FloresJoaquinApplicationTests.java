package ar.org.centro.java.curso.TP2_FloresJoaquin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tp2FloresJoaquinApplicationTests {

	@Test
	void contextLoads() {
	}

}
